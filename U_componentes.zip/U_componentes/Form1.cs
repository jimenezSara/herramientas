﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace U_componentes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnPlay_Click(object sender, EventArgs e)
        {
            wmpVideo.URL = @"C:\\Users\\USUARIO\\Downloads\\ios_18.mp4";
        }

        private void wmpVideo_Enter(object sender, EventArgs e)
        {

        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            webBrowser1.Navigate(textBox1.Text);
        }

        private void btnAbrir_Click(object sender, EventArgs e)
        {
            axAcroPDF1.src = @"C:\\Users\\USUARIO\\source\\repos\\U_componentes\\U_componentes\\bin\\Debug\\El Arte de la Guerra Autor Sun Tzu.pdf";
        }
    }
}
